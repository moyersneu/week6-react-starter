
export enum ActionKeys {
  CLEAR = 'C',
  EQUALS = '=',
  DOT = '•',
  SIGN_FLIP = '±'
}
