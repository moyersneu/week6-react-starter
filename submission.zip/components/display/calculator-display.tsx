
import React from 'react';

export function CalculatorDisplay(arg: any) {
  return <div className="calculator-display">0</div>;
}
